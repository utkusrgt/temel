# pythontemel_proje
project for patika python course
