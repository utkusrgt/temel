liste = [[1, 2], [3, 4], [5, 6, 7]]
liste.reverse()
for item in liste:
    # List Reverse
    item.reverse()

    # updated list
print('Updated List:', liste)
